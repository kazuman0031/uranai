var isPlaying = false;
var sort = false;
var cnt = 0
        var image = document.getElementById('animation');//HTMLのIDを参照するだけ
        
        function toggleAnimation() {
            if (isPlaying && cnt < 5) {
                cnt += 1;

                // 乱数周りの処理
                if(sort == false){
                    var random = getRandom(0, 156); // 0~156の乱数を生成
                }else{
                    var random = getRandom(0, 44); // 0~44の乱数を生成
                }
            
                var text = document.getElementById("request_text"); //テキストエリアのIDタグの参照

                // 乱数に対応する画像生成
                var target1 = document.getElementById( 'target1' );
                var element = '<img src="' + array[random][1] + '" alt="" />';//乱数に対応した画像を配置
                target1.innerHTML += element;

                // テキストの更新
                var next = document.getElementById('next');
                switch (cnt) {
                    case 1:
                        next.innerHTML += "2枚目:障害"+" ";
                        var word = "現在：";    
                        text.innerHTML += word + array[random][0]+ "\n";  // 配列を参照しテキストボックスに配置
                        break;
                    case 2:
                        next.innerHTML += "3枚目:傾向"+" ";
                        word ="障害:";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 3:
                        next.innerHTML += "4枚目:対策"+" ";
                        word ="傾向:";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 4:
                        next.innerHTML += "5枚目:結果"+" ";
                        word ="対策:";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 5:
                        word ="結果:";
                        text.innerHTML += word + array[random][0]+ "\n";
                        image.src = 'image/stop.gif';
                        isPlaying = false;
                        break;
                    }
                        

            } else if(cnt ==0){
                image.src = 'image/start.png'; // GIFの再生が開始される
                isPlaying = true;
                var next = document.getElementById('next');
                var text = "1枚目:現在";
                next.innerHTML = text +"\n";
            }
        }


        // ランダム関数
        function getRandom(min,max) {
            var random = Math.floor( Math.random() * (max + 1 - min) ) + min;
          
            return random;
        }