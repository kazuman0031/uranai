var isPlaying = false;
var sort = false;
var cnt = 0;
        var image = document.getElementById('animation');//HTMLのIDを参照するだけ
        
        function toggleAnimation() {
            if (isPlaying && cnt ==0) {
                image.src = 'image/stop.gif'; //GIFが停止
                cnt = 1;

                // 乱数周りの処理
                if(sort == false){
                    var random = getRandom(0, 156); // 0~156の乱数を生成
                }else{
                    var random = getRandom(0, 44); // 0~44の乱数を生成
                }
                var text = document.getElementById("request_text"); //テキストエリアのIDタグの参照
                text.innerHTML +="引いたカード："+array[random][0]+ "\n";  // 配列を参照しテキストボックスに配置

                // 乱数に対応する画像生成
                var target = document.getElementById( 'target1' );
                var element = '<img src="' + array[random][1] + '" alt="" />';//乱数に対応した画像を配置
                target.innerHTML = element;

            } else if(cnt ==0){
                image.src = 'image/start.png'; // GIFの再生が開始される
                isPlaying = true;
            }
        }


        // ランダム関数
        function getRandom(min,max) {
            var random = Math.floor( Math.random() * (max + 1 - min) ) + min;
          
            return random;
        }
