var isPlaying = false;
var sort = false;
var cnt = 0
        var image = document.getElementById('animation');//HTMLのIDを参照するだけ
        
        function toggleAnimation() {
            if (isPlaying && cnt < 10) {
                cnt += 1;

                // 乱数周りの処理
                if(sort == false){
                    var random = getRandom(0, 156); // 0~156の乱数を生成
                }else{
                    var random = getRandom(0, 44); // 0~44の乱数を生成
                }
            
                var text = document.getElementById("request_text"); //テキストエリアのIDタグの参照

                // 乱数に対応する画像生成
                var target = document.getElementById( 'target1' );
                var element = '<img src="' + array[random][1] + '" alt="" />';//乱数に対応した画像を配置
                target.innerHTML += element;

                // テキストの更新
                var next = document.getElementById('next');
                switch (cnt) {
                    case 1:
                        next.innerHTML += "2枚目:情熱"+" ";
                        var word = "目標：";
                        text.innerHTML += word + array[random][0]+ "\n";  // 配列を参照しテキストボックスに配置
                        break;
                    case 2:
                        next.innerHTML += "3枚目:試練"+" ";
                        word = "情熱：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 3:
                        next.innerHTML += "4枚目:武器"+" ";
                        word = "試練：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 4:
                        next.innerHTML += "5枚目:障害"+" ";
                        word = "武器：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 5:
                        next.innerHTML += "6枚目:達成"+" ";
                        word = "障害：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 6:
                        next.innerHTML += "7枚目:自信"+" ";
                        word = "達成：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 7:
                        next.innerHTML += "8枚目:苦手なこと"+" ";
                        word = "自信：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 8:
                        next.innerHTML += "9枚目:本能"+" ";
                        word = "苦手：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 9:
                        next.innerHTML += "10枚目:現状"+" ";
                        word = "本能：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        break;
                    case 10:
                        word = "現状：";
                        text.innerHTML += word + array[random][0]+ "\n";
                        image.src = 'image/stop.gif';
                        isPlaying = false;   
                        break;
                    }
                        

            } else if(cnt ==0){
                image.src = 'image/start.png'; // GIFの再生が開始される
                var next = document.getElementById('next');
                var text = "1枚目:目標";
                next.innerHTML = text +"\n";
                isPlaying = true;
            }
        }


        // ランダム関数
        function getRandom(min,max) {
            var random = Math.floor( Math.random() * (max + 1 - min) ) + min;
          
            return random;
        }
