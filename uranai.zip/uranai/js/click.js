// 追記ボタンを押すと入力内容をテキストボックスへ
function FirstButtonClick() {
    var textbox = document.getElementById("request_text");
    var title = document.getElementById("title_text").value;
    textbox.innerHTML += "内容："+ title + "\n";
}
function SecondButtonClick() {
    // 二者択一で使う
    var textbox = document.getElementById("request_text");
    var titleA = document.getElementById("title_A").value;
    var titleB = document.getElementById("title_B").value;
    textbox.innerHTML += "内容："+ titleA + "と" + titleB + "\n";
}
// チェックボックスのオンオフ
function onoff() {
    if (document.getElementById("check").checked) {
        sort = true;
    } else {
        sort = false;
  }
}

//テキストボックスは入力不可能
var test = document.getElementById('request_text');
test.readOnly = true;